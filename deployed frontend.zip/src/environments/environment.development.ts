export const environment = {
  apiUrl: 'https://demobkend20250120230339.azurewebsites.net/api/',
};
