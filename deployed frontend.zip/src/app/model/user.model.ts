export interface userregister {
  username: string;
  email: string;
  password: string;
  role: string;
}
 