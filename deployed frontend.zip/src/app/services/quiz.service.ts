import { Injectable } from '@angular/core';
import { Observable, from } from 'rxjs';
import Groq from 'groq-sdk';

@Injectable({
  providedIn: 'root',
})
export class QuizService {
  private groq: Groq;

  constructor() {
    // Initialize Groq with API key and browser support
    this.groq = new Groq({
      apiKey: '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', 
      dangerouslyAllowBrowser: true, // Enable browser support
    });
  }

  // Function to get a response from the Groq API
  getChatCompletion(topic: string): Observable<any> {
    const promise = this.groq.chat.completions.create({
      messages: [
        {
          role: 'system',
          content:
            'Generate a JSON response for a quiz in the following format: {"quiz": {"questions": [{"question": "...", "options": {"A": "...", "B": "...", "C": "...", "D": "..."}, "correctAnswer": "A/B/C/D", "explanation": "..."}]}}. The response should include 10 questions based on the topic provided, each with options (A, B, C, D), only one correct answer, and explanations for each question.',
        },
        {
          role: 'user',
          content: `Generate a quiz on: ${topic}`,
        },
      ],
      model: 'llama-3.3-70b-versatile',
      temperature: 0.7,
    });

    // Convert Promise to Observable
    return from(promise);
  }
}
