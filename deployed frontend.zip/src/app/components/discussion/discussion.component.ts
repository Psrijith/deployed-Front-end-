import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { environment } from '../../../environments/environment.development';
import { SessionStorageService } from '../../sessionstorage.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-discussion',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './discussion.component.html',
  styleUrls: ['./discussion.component.css'],
})
export class DiscussionComponent implements OnInit {
  role: string | null = null;
  discussions: any[] = [];
  newDiscussionForm: FormGroup;
  apiUrl: string = `${environment.apiUrl}Discussion/discussions`;
  replies: { [discussionId: number]: string[] } = {};

  constructor(
    private http: HttpClient,
    private fb: FormBuilder,
    private SessionStorageService: SessionStorageService
  ) {
    this.newDiscussionForm = this.fb.group({
      courseId: [0],
      userId: [0],
      postContent: [''],
      postDate: [new Date().toISOString()],
      status: ['Closed'],
    });
  }

  ngOnInit(): void {
    this.role = this.SessionStorageService.getItem('role');
    this.fetchDiscussions();
    this.loadRepliesFromLocalStorage();
  }

  fetchDiscussions(): void {
    this.http.get<any[]>(this.apiUrl).subscribe(
      (data) => {
        this.discussions = data;
      },
      (error) => {
        console.error('Error fetching discussions', error);
      }
    );
  }

  postDiscussion(): void {
    const newDiscussion = this.newDiscussionForm.value;
    this.http
      .post<any>(`${environment.apiUrl}Discussion/discussion`, newDiscussion)
      .subscribe(
        () => {
          this.fetchDiscussions();
          this.newDiscussionForm.reset();
        },
        (error) => {
          console.error('Error posting discussion', error);
        }
      );
  }

  loadRepliesFromLocalStorage(): void {
    const storedReplies = localStorage.getItem('replies');
    if (storedReplies) {
      this.replies = JSON.parse(storedReplies);
    }
  }

  saveRepliesToLocalStorage(): void {
    localStorage.setItem('replies', JSON.stringify(this.replies));
  }

  addReply(discussionId: number, replyContent: string, discussion: any): void {
    if (!replyContent.trim()) return; // Prevent empty replies
    if (!this.replies[discussionId]) {
      this.replies[discussionId] = [];
    }
    this.replies[discussionId].push(replyContent);
    this.saveRepliesToLocalStorage();
    discussion.newReply = '';
  }

  deleteReply(discussionId: number, replyIndex: number): void {
    if (this.replies[discussionId]) {
      this.replies[discussionId].splice(replyIndex, 1);
      if (this.replies[discussionId].length === 0) {
        delete this.replies[discussionId]; // Remove discussion ID if no replies are left
      }
      this.saveRepliesToLocalStorage();
    }
  }

  getReplies(discussionId: number): string[] {
    return this.replies[discussionId] || [];
  }

  splitReplyIntoWords(reply: string): string[] {
    const words = reply.split(' ');
    const maxWordsPerLine = 15;
    const lines: string[] = [];
    for (let i = 0; i < words.length; i += maxWordsPerLine) {
      lines.push(words.slice(i, i + maxWordsPerLine).join(' '));
    }
    return lines;
  }

  markDiscussionAsOpen(discussionId: number): void {
    this.http
      .put<any>(
        `${environment.apiUrl}Discussion/discussion/${discussionId}/open`,
        {}
      )
      .subscribe(
        () => {
          this.fetchDiscussions();
        },
        (error) => {
          console.error('Error marking discussion as open', error);
        }
      );
  }

  markDiscussionAsClosed(discussionId: number): void {
    this.http
      .put<any>(
        `${environment.apiUrl}Discussion/discussion/${discussionId}/close`,
        {}
      )
      .subscribe(
        () => {
          this.fetchDiscussions();
        },
        (error) => {
          console.error('Error marking discussion as closed', error);
        }
      );
  }
}
