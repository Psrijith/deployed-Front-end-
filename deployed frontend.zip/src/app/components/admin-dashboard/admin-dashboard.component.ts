import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { environment } from '../../../environments/environment.development';
import Chart from 'chart.js/auto';
import { interval, Subscription } from 'rxjs';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css'],
})
export class AdminDashboardComponent implements OnInit, OnDestroy {
  // Dashboard Statistics
  totalUsers: number = 0;
  totalCourses: number = 0;
  activeInstructors: number = 0;
  totalEnrollments: number = 0;
  userRoles: { [key: string]: number } = {};
  coursesByCategory: { [key: string]: number } = {};
  courseDifficultyLevels: { [key: string]: number } = {};

  // Timer-related properties
  sessionDuration: number = 120; // 120 minutes
  remainingTime: number = this.sessionDuration * 60; // convert to seconds
  timerSubscription: Subscription | null = null;

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchUsers();
    this.fetchCourses();
    this.initializeCharts();
    this.startSessionTimer();
  }

  ngOnDestroy() {
    // Clean up the timer subscription when the component is destroyed
    if (this.timerSubscription) {
      this.timerSubscription.unsubscribe();
    }
  }

  startSessionTimer() {
    // Create an interval that ticks every second
    this.timerSubscription = interval(1000).subscribe(() => {
      // Decrease remaining time
      this.remainingTime--;

      // Log the remaining time for debugging
      console.log(`Remaining time: ${this.remainingTime} seconds`);

      // Check if time has expired
      if (this.remainingTime <= 0) {
        this.handleSessionExpired();
      }
    });
  }

  handleSessionExpired() {
    // Stop the timer
    if (this.timerSubscription) {
      this.timerSubscription.unsubscribe();
    }

    // Log session expiry for debugging
    console.log('Session expired. Please log in again.');

    // Optionally, perform actions like logging out or showing an alert
    alert('Session has expired. Please log in again.');
  }

  // Format time to MM:SS format
  formatTime(seconds: number): string {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${this.padZero(minutes)}:${this.padZero(remainingSeconds)}`;
  }

  // Helper method to add leading zero
  padZero(num: number): string {
    return num.toString().padStart(2, '0');
  }

  fetchUsers() {
    this.http.get(environment.apiUrl + 'User').subscribe((response: any) => {
      this.totalUsers = response.length;
      console.log('User response = ', response);
      response.forEach((user: any) => {
        this.userRoles[user.role] = (this.userRoles[user.role] || 0) + 1;
      });

      this.activeInstructors = response.filter(
        (user: any) => user.isActive && user.role === 'Instructor'
      ).length;

      this.initializeUserRolesChart();
    });
  }

  fetchCourses() {
    this.http.get(environment.apiUrl + 'Course').subscribe((response: any) => {
      this.totalCourses = response.length;
      console.log('course response= ', response);
      response.forEach((course: any) => {
        this.coursesByCategory[course.category] =
          (this.coursesByCategory[course.category] || 0) + 1;
        this.courseDifficultyLevels[course.difficultyLevel] =
          (this.courseDifficultyLevels[course.difficultyLevel] || 0) + 1;
      });

      this.initializeCoursesCategoryChart();
      this.initializeDifficultyLevelChart();
    });

    this.http
      .get('https://demobkend20250120230339.azurewebsites.net/api/Enrollment/total/enrollments/count')
      .subscribe((response: any) => {
        this.totalEnrollments = response;
      });
  }

  initializeUserRolesChart() {
    const ctx = document.getElementById('userRolesChart') as HTMLCanvasElement;
    new Chart(ctx, {
      type: 'pie',
      data: {
        labels: Object.keys(this.userRoles),
        datasets: [
          {
            data: Object.values(this.userRoles),
            backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'],
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
      },
    });
  }

  initializeCoursesCategoryChart() {
    const ctx = document.getElementById(
      'coursesCategoryChart'
    ) as HTMLCanvasElement;
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: Object.keys(this.coursesByCategory),
        datasets: [
          {
            label: 'Courses per Category',
            data: Object.values(this.coursesByCategory),
            backgroundColor: '#36A2EB',
          },
        ],
      },
      options: {
        responsive: true,
      },
    });
  }

  initializeDifficultyLevelChart() {
    const ctx = document.getElementById(
      'difficultyLevelChart'
    ) as HTMLCanvasElement;

    new Chart(ctx, {
      type: 'line',
      data: {
        labels: Object.keys(this.courseDifficultyLevels),
        datasets: [
          {
            label: 'Course Difficulty Level',
            data: Object.values(this.courseDifficultyLevels),
            borderColor: 'rgba(255, 99, 132, 1)',
            backgroundColor: 'rgba(255, 99, 132, 0.2)',
            fill: true,
            borderWidth: 3,
            tension: 0.4,
            pointBackgroundColor: 'rgba(255, 99, 132, 1)',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointRadius: 6,
            pointHoverBackgroundColor: 'rgba(255, 99, 132, 1)',
            pointHoverBorderColor: '#fff',
            pointHoverBorderWidth: 3,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
          },
        },
        scales: {
          x: {
            beginAtZero: true,
          },
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1,
            },
          },
        },
        animation: {
          duration: 1000,
          easing: 'easeInOutQuad',
        },
      },
    });
  }

  initializeCharts() {
    const ctx = document.getElementById('yourChartId') as HTMLCanvasElement;
    new Chart(ctx, {
      type: 'pie',
      data: {
        labels: ['Label1', 'Label2', 'Label3'],
        datasets: [
          {
            data: [10, 20, 30],
            backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'],
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
      },
    });
  }
}
