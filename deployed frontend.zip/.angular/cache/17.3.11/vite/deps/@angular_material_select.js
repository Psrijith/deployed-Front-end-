import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-AMONQ7HW.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-BVW6H7CP.js";
import "./chunk-JXJVAWPV.js";
import "./chunk-G7BHKBYE.js";
import "./chunk-2YKAUAWY.js";
import "./chunk-422GVE3F.js";
import "./chunk-OYOIOTKQ.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-4HIFHHBJ.js";
import "./chunk-LCFNAIYZ.js";
import "./chunk-WKU6PVB3.js";
import "./chunk-CO2UG7VT.js";
import "./chunk-HMLPZKPQ.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
